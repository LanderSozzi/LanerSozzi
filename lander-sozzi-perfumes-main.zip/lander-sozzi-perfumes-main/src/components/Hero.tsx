import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-perfume.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50" />
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 pt-20">
        <div className="max-w-2xl animate-fade-up">
          <p className="text-elegant text-primary mb-6 opacity-0 animate-fade-up delay-100">
            Exclusividade & Sofisticação
          </p>

          <h1 className="font-display text-4xl md:text-6xl lg:text-7xl text-foreground mb-6 leading-tight opacity-0 animate-fade-up delay-200">
            A Arte de{" "}
            <span className="text-gradient-gold">Seduzir</span>
            <br />
            pelo Perfume
          </h1>

          <p className="text-muted-foreground text-lg md:text-xl mb-10 max-w-xl leading-relaxed opacity-0 animate-fade-up delay-300">
            Descubra fragrâncias únicas que contam histórias. Cada perfume Lander
            Sozzi é uma experiência sensorial incomparável.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 opacity-0 animate-fade-up delay-400">
            <Link to="/colecao">
              <Button variant="hero" size="xl">
                Explorar Coleção
              </Button>
            </Link>
            <Link to="/sobre">
              <Button variant="elegant" size="xl">
                Nossa História
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-0 animate-fade-up delay-500">
        <span className="text-xs tracking-widest uppercase text-muted-foreground">
          Scroll
        </span>
        <div className="w-px h-12 bg-gradient-to-b from-primary to-transparent animate-pulse" />
      </div>
    </section>
  );
};

export default Hero;
