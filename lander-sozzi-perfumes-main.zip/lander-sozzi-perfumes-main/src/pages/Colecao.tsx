import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { products } from "@/data/products";

const Colecao = () => {
  const [activeFilter, setActiveFilter] = useState("todos");

  const filters = [
    { id: "todos", label: "Todos" },
    { id: "masculino", label: "Masculinos" },
    { id: "feminino", label: "Femininos" },
    { id: "unissex", label: "Unissex" },
  ];

  const filteredProducts =
    activeFilter === "todos"
      ? products
      : products.filter((p) => p.category === activeFilter);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-24">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center mb-16">
            <p className="text-elegant text-primary mb-4">Explore</p>
            <h1 className="font-display text-4xl md:text-6xl text-foreground mb-6">
              Nossa <span className="text-gradient-gold">Coleção</span>
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Descubra fragrâncias únicas, cuidadosamente elaboradas para
              despertar emoções e criar memórias inesquecíveis.
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {filters.map((filter) => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id)}
                className={`px-6 py-3 text-sm tracking-widest uppercase transition-all duration-300 ${
                  activeFilter === filter.id
                    ? "bg-gradient-gold text-primary-foreground"
                    : "border border-border text-muted-foreground hover:border-primary hover:text-primary"
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Colecao;
