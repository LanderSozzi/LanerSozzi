import { useParams, Link } from "react-router-dom";
import { useState } from "react";
import { Minus, Plus, Heart, ShoppingBag, ArrowLeft } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { products } from "@/data/products";
import { useCart } from "@/hooks/useCart";
import ProductCard from "@/components/ProductCard";

const Produto = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === Number(id));
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToCart } = useCart();

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-3xl text-foreground mb-4">
            Produto não encontrado
          </h1>
          <Link to="/colecao" className="text-primary hover:underline">
            Voltar à coleção
          </Link>
        </div>
      </div>
    );
  }

  const formatPrice = (price: number) => {
    return price.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  };

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-24">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <Link
            to="/colecao"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8"
          >
            <ArrowLeft size={16} />
            Voltar à Coleção
          </Link>

          {/* Product Detail */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 mb-24">
            {/* Image */}
            <div className="relative">
              <div className="aspect-square bg-noir-light overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.bestseller && (
                  <span className="bg-primary text-primary-foreground text-[10px] tracking-widest uppercase px-3 py-1">
                    Bestseller
                  </span>
                )}
                {product.new && (
                  <span className="bg-foreground text-background text-[10px] tracking-widest uppercase px-3 py-1">
                    Novo
                  </span>
                )}
              </div>
            </div>

            {/* Info */}
            <div className="space-y-8">
              <div>
                <p className="text-elegant text-primary mb-2">
                  {product.category}
                </p>
                <h1 className="font-display text-4xl md:text-5xl text-foreground mb-4">
                  {product.name}
                </h1>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Price */}
              <div className="flex items-baseline gap-4">
                <span className="text-3xl font-medium text-primary">
                  {formatPrice(product.price)}
                </span>
                {product.originalPrice && (
                  <span className="text-xl text-muted-foreground line-through">
                    {formatPrice(product.originalPrice)}
                  </span>
                )}
              </div>

              {/* Size */}
              <div>
                <p className="text-sm text-muted-foreground mb-2">Tamanho</p>
                <span className="inline-block border border-primary px-4 py-2 text-foreground">
                  {product.size}
                </span>
              </div>

              {/* Notes */}
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">Notas Olfativas</p>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-4 glass-card">
                    <p className="text-xs text-primary mb-2 uppercase tracking-widest">
                      Topo
                    </p>
                    <p className="text-sm text-foreground">
                      {product.notes.top.join(", ")}
                    </p>
                  </div>
                  <div className="text-center p-4 glass-card">
                    <p className="text-xs text-primary mb-2 uppercase tracking-widest">
                      Coração
                    </p>
                    <p className="text-sm text-foreground">
                      {product.notes.heart.join(", ")}
                    </p>
                  </div>
                  <div className="text-center p-4 glass-card">
                    <p className="text-xs text-primary mb-2 uppercase tracking-widest">
                      Base
                    </p>
                    <p className="text-sm text-foreground">
                      {product.notes.base.join(", ")}
                    </p>
                  </div>
                </div>
              </div>

              {/* Quantity & Add to Cart */}
              <div className="flex flex-col sm:flex-row gap-4">
                {/* Quantity Selector */}
                <div className="flex items-center border border-border">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-4 hover:bg-muted transition-colors"
                  >
                    <Minus size={16} />
                  </button>
                  <span className="px-6 text-foreground">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-4 hover:bg-muted transition-colors"
                  >
                    <Plus size={16} />
                  </button>
                </div>

                {/* Add to Cart */}
                <Button
                  onClick={handleAddToCart}
                  variant="gold"
                  size="xl"
                  className="flex-1"
                >
                  <ShoppingBag size={18} />
                  Adicionar ao Carrinho
                </Button>

                {/* Favorite */}
                <button
                  onClick={() => setIsFavorite(!isFavorite)}
                  className="p-4 border border-border hover:border-primary transition-colors"
                >
                  <Heart
                    size={20}
                    className={
                      isFavorite ? "fill-primary text-primary" : "text-foreground"
                    }
                  />
                </button>
              </div>
            </div>
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <section>
              <h2 className="font-display text-2xl md:text-3xl text-foreground mb-8 text-center">
                Produtos <span className="text-gradient-gold">Relacionados</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {relatedProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Produto;
