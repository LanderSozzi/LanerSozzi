import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, ArrowLeft, ShoppingBag } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";

const Carrinho = () => {
  const { cartItems, removeFromCart, updateQuantity, total, clearCart } = useCart();

  const formatPrice = (price: number) => {
    return price.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="pt-32 pb-24">
          <div className="container mx-auto px-4">
            <div className="text-center py-20">
              <ShoppingBag size={64} className="mx-auto text-muted-foreground mb-6" />
              <h1 className="font-display text-3xl text-foreground mb-4">
                Seu Carrinho Está Vazio
              </h1>
              <p className="text-muted-foreground mb-8">
                Explore nossa coleção e encontre fragrâncias incríveis.
              </p>
              <Link to="/colecao">
                <Button variant="gold" size="lg">
                  Explorar Coleção
                </Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-24">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-12">
            <div>
              <Link
                to="/colecao"
                className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-4"
              >
                <ArrowLeft size={16} />
                Continuar Comprando
              </Link>
              <h1 className="font-display text-3xl md:text-4xl text-foreground">
                Seu <span className="text-gradient-gold">Carrinho</span>
              </h1>
            </div>
            <button
              onClick={clearCart}
              className="text-sm text-muted-foreground hover:text-destructive transition-colors"
            >
              Limpar Carrinho
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-6">
              {cartItems.map((item) => (
                <div
                  key={item.product.id}
                  className="flex gap-6 p-6 glass-card"
                >
                  {/* Image */}
                  <Link
                    to={`/produto/${item.product.id}`}
                    className="w-24 h-24 md:w-32 md:h-32 bg-noir-light flex-shrink-0"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  {/* Info */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-xs tracking-widest uppercase text-primary mb-1">
                        {item.product.category}
                      </p>
                      <Link
                        to={`/produto/${item.product.id}`}
                        className="font-display text-lg text-foreground hover:text-primary transition-colors"
                      >
                        {item.product.name}
                      </Link>
                      <p className="text-sm text-muted-foreground">
                        {item.product.size}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-4">
                      {/* Quantity */}
                      <div className="flex items-center border border-border">
                        <button
                          onClick={() =>
                            updateQuantity(item.product.id, item.quantity - 1)
                          }
                          className="p-2 hover:bg-muted transition-colors"
                        >
                          <Minus size={14} />
                        </button>
                        <span className="px-4 text-sm text-foreground">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(item.product.id, item.quantity + 1)
                          }
                          className="p-2 hover:bg-muted transition-colors"
                        >
                          <Plus size={14} />
                        </button>
                      </div>

                      {/* Price & Remove */}
                      <div className="flex items-center gap-4">
                        <span className="text-lg font-medium text-primary">
                          {formatPrice(item.product.price * item.quantity)}
                        </span>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="glass-card p-8 sticky top-32">
                <h2 className="font-display text-xl text-foreground mb-6">
                  Resumo do Pedido
                </h2>

                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Subtotal</span>
                    <span>{formatPrice(total)}</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>Frete</span>
                    <span className="text-primary">Grátis</span>
                  </div>
                </div>

                <div className="border-t border-border pt-4 mb-8">
                  <div className="flex justify-between text-foreground">
                    <span className="font-medium">Total</span>
                    <span className="text-xl font-medium text-primary">
                      {formatPrice(total)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    ou 12x de {formatPrice(total / 12)} sem juros
                  </p>
                </div>

                <Button variant="gold" size="xl" className="w-full mb-4">
                  Finalizar Compra
                </Button>

                <p className="text-center text-xs text-muted-foreground">
                  Pagamento 100% seguro via PIX, cartão ou boleto
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Carrinho;
