import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import perfumeMasculino from "@/assets/perfume-masculino.jpg";
import perfumeFeminino from "@/assets/perfume-feminino.jpg";
import perfumeUnissex from "@/assets/perfume-unissex.jpg";

const Categories = () => {
  const categories = [
    {
      name: "Masculinos",
      description: "Fragrâncias intensas e marcantes",
      image: perfumeMasculino,
      href: "/masculinos",
    },
    {
      name: "Femininos",
      description: "Elegância e sofisticação em cada nota",
      image: perfumeFeminino,
      href: "/femininos",
    },
    {
      name: "Unissex",
      description: "Para todos os estilos",
      image: perfumeUnissex,
      href: "/unissex",
    },
  ];

  return (
    <section className="py-24 bg-noir-light">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-elegant text-primary mb-4">Explore por Categoria</p>
          <h2 className="font-display text-3xl md:text-5xl text-foreground">
            Encontre Sua{" "}
            <span className="text-gradient-gold">Essência</span>
          </h2>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((category, index) => (
            <Link
              key={category.name}
              to={category.href}
              className="group relative overflow-hidden aspect-[3/4] md:aspect-[4/5]"
            >
              {/* Image */}
              <img
                src={category.image}
                alt={category.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

              {/* Content */}
              <div className="absolute inset-0 p-8 flex flex-col justify-end">
                <div className="transform transition-transform duration-500 group-hover:-translate-y-2">
                  <p className="text-xs tracking-widest uppercase text-primary mb-2">
                    Coleção
                  </p>
                  <h3 className="font-display text-3xl text-foreground mb-2 flex items-center gap-3">
                    {category.name}
                    <ArrowUpRight
                      size={24}
                      className="opacity-0 -translate-x-4 transition-all duration-500 group-hover:opacity-100 group-hover:translate-x-0 text-primary"
                    />
                  </h3>
                  <p className="text-muted-foreground">
                    {category.description}
                  </p>
                </div>
              </div>

              {/* Border Effect */}
              <div className="absolute inset-0 border border-primary/0 group-hover:border-primary/30 transition-colors duration-500" />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
