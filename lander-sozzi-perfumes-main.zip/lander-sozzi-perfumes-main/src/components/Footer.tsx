import { Link } from "react-router-dom";
import { Instagram, Facebook, MessageCircle } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-noir-light border-t border-border">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <div>
              <h3 className="font-display text-2xl tracking-[0.2em] text-foreground">
                LANDER SOZZI
              </h3>
              <p className="text-xs tracking-[0.4em] text-primary uppercase">
                Perfums
              </p>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Fragrâncias exclusivas que contam histórias. Cada perfume é uma
              jornada sensorial única, criada para despertar emoções.
            </p>
            <div className="flex gap-4">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 border border-border rounded-full hover:border-primary hover:text-primary transition-colors"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 border border-border rounded-full hover:border-primary hover:text-primary transition-colors"
              >
                <Facebook size={18} />
              </a>
              <a
                href="https://wa.me/5511999999999"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 border border-border rounded-full hover:border-primary hover:text-primary transition-colors"
              >
                <MessageCircle size={18} />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-elegant text-foreground mb-6">Navegação</h4>
            <ul className="space-y-3">
              {["Início", "Coleção", "Masculinos", "Femininos", "Sobre"].map(
                (item) => (
                  <li key={item}>
                    <Link
                      to={`/${item.toLowerCase()}`}
                      className="text-muted-foreground hover:text-primary transition-colors text-sm"
                    >
                      {item}
                    </Link>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Atendimento */}
          <div>
            <h4 className="text-elegant text-foreground mb-6">Atendimento</h4>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>Segunda a Sexta: 9h às 18h</li>
              <li>Sábado: 9h às 13h</li>
              <li>contato@landersozzi.com</li>
              <li>(11) 99999-9999</li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-elegant text-foreground mb-6">Newsletter</h4>
            <p className="text-muted-foreground text-sm mb-4">
              Receba novidades e ofertas exclusivas.
            </p>
            <form className="space-y-3">
              <input
                type="email"
                placeholder="Seu e-mail"
                className="w-full bg-transparent border border-border rounded px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
              />
              <button
                type="submit"
                className="w-full bg-gradient-gold text-primary-foreground py-3 text-sm tracking-widest uppercase font-medium hover:shadow-[0_4px_20px_hsl(43_74%_49%_/_0.3)] transition-all"
              >
                Inscrever
              </button>
            </form>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-xs">
            © 2024 Lander Sozzi Perfums. Todos os direitos reservados.
          </p>
          <div className="flex gap-6 text-xs text-muted-foreground">
            <Link to="/privacidade" className="hover:text-primary transition-colors">
              Política de Privacidade
            </Link>
            <Link to="/termos" className="hover:text-primary transition-colors">
              Termos de Uso
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
