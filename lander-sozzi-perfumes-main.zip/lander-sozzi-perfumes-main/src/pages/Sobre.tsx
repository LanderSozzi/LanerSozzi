import Header from "@/components/Header";
import Footer from "@/components/Footer";
import perfumeCollection from "@/assets/perfume-collection.jpg";
import { Award, Leaf, Heart, Shield } from "lucide-react";

const Sobre = () => {
  const values = [
    {
      icon: Award,
      title: "Excelência",
      description:
        "Utilizamos apenas os ingredientes mais nobres e raros do mundo da perfumaria.",
    },
    {
      icon: Leaf,
      title: "Sustentabilidade",
      description:
        "Comprometidos com práticas sustentáveis em toda nossa cadeia de produção.",
    },
    {
      icon: Heart,
      title: "Paixão",
      description:
        "Cada fragrância é criada com amor e dedicação por nossos mestres perfumistas.",
    },
    {
      icon: Shield,
      title: "Qualidade",
      description:
        "Rigoroso controle de qualidade para garantir a perfeição em cada frasco.",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-32 pb-24">
        {/* Hero */}
        <section className="container mx-auto px-4 mb-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <p className="text-elegant text-primary mb-4">Quem Somos</p>
              <h1 className="font-display text-4xl md:text-6xl text-foreground mb-6">
                A Essência da{" "}
                <span className="text-gradient-gold">Lander Sozzi</span>
              </h1>
              <div className="space-y-6 text-muted-foreground leading-relaxed">
                <p>
                  Fundada com a missão de trazer o melhor da perfumaria
                  internacional para o Brasil, a Lander Sozzi nasceu da paixão
                  por fragrâncias únicas e da busca incansável pela excelência.
                </p>
                <p>
                  Nossa história começou há mais de uma década, quando nosso
                  fundador, após anos de estudo e imersão no universo da
                  perfumaria francesa, decidiu criar uma marca que unisse a
                  tradição artesanal europeia com a sofisticação brasileira.
                </p>
                <p>
                  Hoje, somos reconhecidos por criar composições exclusivas que
                  transcendem o ordinário, utilizando ingredientes naturais de
                  altíssima qualidade, selecionados pessoalmente em viagens ao
                  redor do mundo.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src={perfumeCollection}
                alt="Nossa Coleção"
                className="w-full aspect-square object-cover"
              />
              <div className="absolute -bottom-8 -right-8 w-full h-full border border-primary/30 -z-10" />
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="bg-noir-light py-24">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <p className="text-elegant text-primary mb-4">Nossos Valores</p>
              <h2 className="font-display text-3xl md:text-5xl text-foreground">
                O Que Nos{" "}
                <span className="text-gradient-gold">Define</span>
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <div
                  key={index}
                  className="glass-card p-8 text-center hover-lift"
                >
                  <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center">
                    <value.icon size={28} className="text-primary" />
                  </div>
                  <h3 className="font-display text-xl text-foreground mb-3">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">
                    {value.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Stats */}
        <section className="py-24">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <p className="font-display text-5xl md:text-6xl text-primary mb-2">
                  10+
                </p>
                <p className="text-elegant text-muted-foreground">
                  Anos de Experiência
                </p>
              </div>
              <div className="text-center">
                <p className="font-display text-5xl md:text-6xl text-primary mb-2">
                  50+
                </p>
                <p className="text-elegant text-muted-foreground">
                  Fragrâncias Criadas
                </p>
              </div>
              <div className="text-center">
                <p className="font-display text-5xl md:text-6xl text-primary mb-2">
                  15k+
                </p>
                <p className="text-elegant text-muted-foreground">
                  Clientes Satisfeitos
                </p>
              </div>
              <div className="text-center">
                <p className="font-display text-5xl md:text-6xl text-primary mb-2">
                  5★
                </p>
                <p className="text-elegant text-muted-foreground">
                  Avaliação Média
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Sobre;
