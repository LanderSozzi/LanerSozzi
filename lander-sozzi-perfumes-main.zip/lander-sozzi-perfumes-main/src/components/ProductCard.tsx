import { useState } from "react";
import { Link } from "react-router-dom";
import { ShoppingBag, Heart } from "lucide-react";
import { Product } from "@/data/products";
import { useCart } from "@/hooks/useCart";
import { Button } from "./ui/button";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToCart } = useCart();

  const formatPrice = (price: number) => {
    return price.toLocaleString("pt-BR", {
      style: "currency",
      currency: "BRL",
    });
  };

  return (
    <div
      className="group relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative overflow-hidden bg-noir-light aspect-[3/4] mb-4">
        <Link to={`/produto/${product.id}`}>
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
        </Link>

        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {product.bestseller && (
            <span className="bg-primary text-primary-foreground text-[10px] tracking-widest uppercase px-3 py-1">
              Bestseller
            </span>
          )}
          {product.new && (
            <span className="bg-foreground text-background text-[10px] tracking-widest uppercase px-3 py-1">
              Novo
            </span>
          )}
          {product.originalPrice && (
            <span className="bg-destructive text-destructive-foreground text-[10px] tracking-widest uppercase px-3 py-1">
              Oferta
            </span>
          )}
        </div>

        {/* Favorite Button */}
        <button
          onClick={() => setIsFavorite(!isFavorite)}
          className="absolute top-4 right-4 p-2 bg-background/80 backdrop-blur-sm rounded-full transition-all duration-300 hover:bg-background"
        >
          <Heart
            size={18}
            className={
              isFavorite
                ? "fill-primary text-primary"
                : "text-foreground"
            }
          />
        </button>

        {/* Quick Add */}
        <div
          className={`absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background to-transparent transition-all duration-500 ${
            isHovered
              ? "opacity-100 translate-y-0"
              : "opacity-0 translate-y-4"
          }`}
        >
          <Button
            onClick={() => addToCart(product)}
            variant="gold"
            className="w-full"
          >
            <ShoppingBag size={16} />
            Adicionar ao Carrinho
          </Button>
        </div>
      </div>

      {/* Product Info */}
      <div className="space-y-2">
        <p className="text-xs tracking-widest uppercase text-muted-foreground">
          {product.category}
        </p>
        <Link to={`/produto/${product.id}`}>
          <h3 className="font-display text-lg text-foreground group-hover:text-primary transition-colors">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {product.description}
        </p>
        <div className="flex items-center gap-3 pt-2">
          <span className="text-lg font-medium text-primary">
            {formatPrice(product.price)}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
