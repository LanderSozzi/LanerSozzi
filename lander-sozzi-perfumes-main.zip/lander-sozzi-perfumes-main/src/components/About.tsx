import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import perfumeCollection from "@/assets/perfume-collection.jpg";

const About = () => {
  return (
    <section className="py-24 bg-background overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div className="relative">
            <div className="relative z-10">
              <img
                src={perfumeCollection}
                alt="Coleção Lander Sozzi"
                className="w-full aspect-square object-cover"
              />
            </div>
            {/* Decorative Elements */}
            <div className="absolute -top-8 -right-8 w-full h-full border border-primary/30 -z-0" />
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-gold opacity-20 blur-3xl" />
          </div>

          {/* Content */}
          <div className="space-y-8">
            <div>
              <p className="text-elegant text-primary mb-4">Nossa História</p>
              <h2 className="font-display text-3xl md:text-5xl text-foreground mb-6">
                A Arte da{" "}
                <span className="text-gradient-gold">Perfumaria</span>
              </h2>
            </div>

            <div className="space-y-6 text-muted-foreground leading-relaxed">
              <p>
                A Lander Sozzi nasceu da paixão por fragrâncias únicas e da
                busca incansável pela excelência. Cada perfume que criamos é
                resultado de anos de pesquisa e do uso dos ingredientes mais
                nobres do mundo.
              </p>
              <p>
                Trabalhamos com os melhores perfumistas da indústria para
                desenvolver composições que transcendem o comum. Nossas
                fragrâncias não são apenas perfumes – são experiências
                sensoriais que contam histórias e criam memórias.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 py-8 border-y border-border">
              <div className="text-center">
                <p className="font-display text-3xl text-primary mb-1">10+</p>
                <p className="text-xs tracking-widest uppercase text-muted-foreground">
                  Anos de Expertise
                </p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl text-primary mb-1">50+</p>
                <p className="text-xs tracking-widest uppercase text-muted-foreground">
                  Fragrâncias
                </p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl text-primary mb-1">15k+</p>
                <p className="text-xs tracking-widest uppercase text-muted-foreground">
                  Clientes
                </p>
              </div>
            </div>

            <Link to="/sobre">
              <Button variant="goldOutline" size="lg">
                Conheça Nossa História
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
