import perfumeMasculino from "@/assets/perfume-masculino.jpg";
import perfumeFeminino from "@/assets/perfume-feminino.jpg";
import perfumeUnissex from "@/assets/perfume-unissex.jpg";
import perfumeNoir from "@/assets/perfume-noir.jpg";
import perfumeIntense from "@/assets/perfume-intense.jpg";
import perfumeFresh from "@/assets/perfume-fresh.jpg";

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: "masculino" | "feminino" | "unissex";
  notes: {
    top: string[];
    heart: string[];
    base: string[];
  };
  size: string;
  bestseller?: boolean;
  new?: boolean;
}

export const products: Product[] = [
  {
    id: 1,
    name: "Noir Élégance",
    description:
      "Uma fragrância intensa e misteriosa, perfeita para noites especiais. Notas amadeiradas com um toque de especiarias.",
    price: 389.9,
    originalPrice: 459.9,
    image: perfumeNoir,
    category: "masculino",
    notes: {
      top: ["Bergamota", "Pimenta Preta"],
      heart: ["Oud", "Rosa"],
      base: ["Âmbar", "Almíscar"],
    },
    size: "100ml",
    bestseller: true,
  },
  {
    id: 2,
    name: "Rose Mystique",
    description:
      "A essência da feminilidade em um frasco. Notas florais delicadas com um final sofisticado e envolvente.",
    price: 429.9,
    image: perfumeFeminino,
    category: "feminino",
    notes: {
      top: ["Rosa Damascena", "Framboesa"],
      heart: ["Peônia", "Jasmim"],
      base: ["Sândalo", "Vanília"],
    },
    size: "100ml",
    new: true,
  },
  {
    id: 3,
    name: "Amber Fusion",
    description:
      "Uma combinação única de notas orientais e amadeiradas. Ideal para quem busca uma fragrância marcante e atemporal.",
    price: 359.9,
    image: perfumeUnissex,
    category: "unissex",
    notes: {
      top: ["Cardamomo", "Gengibre"],
      heart: ["Canela", "Noz-moscada"],
      base: ["Âmbar", "Cedro"],
    },
    size: "100ml",
    bestseller: true,
  },
  {
    id: 4,
    name: "Intense Passion",
    description:
      "Uma explosão de sensualidade. Notas ricas e envolventes que deixam uma marca inesquecível.",
    price: 479.9,
    image: perfumeIntense,
    category: "feminino",
    notes: {
      top: ["Açafrão", "Íris"],
      heart: ["Rosa Turca", "Oud"],
      base: ["Âmbar Cinza", "Almíscar"],
    },
    size: "100ml",
  },
  {
    id: 5,
    name: "Fresh Ocean",
    description:
      "Frescor marinho com toques cítricos. Perfeito para o dia a dia e ocasiões descontraídas.",
    price: 289.9,
    image: perfumeFresh,
    category: "masculino",
    notes: {
      top: ["Limão Siciliano", "Toranja"],
      heart: ["Notas Marinhas", "Lavanda"],
      base: ["Cedro", "Almíscar Branco"],
    },
    size: "100ml",
    new: true,
  },
  {
    id: 6,
    name: "Velvet Dreams",
    description:
      "Suavidade e elegância em cada borrifada. Uma fragrância que envolve e encanta.",
    price: 399.9,
    image: perfumeMasculino,
    category: "unissex",
    notes: {
      top: ["Pera", "Bergamota"],
      heart: ["Orquídea", "Íris"],
      base: ["Sândalo", "Baunilha"],
    },
    size: "100ml",
  },
];

export const getProductsByCategory = (category: string) => {
  if (category === "todos") return products;
  return products.filter((product) => product.category === category);
};

export const getBestsellers = () => {
  return products.filter((product) => product.bestseller);
};

export const getNewProducts = () => {
  return products.filter((product) => product.new);
};
