import { useState } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Marina Silva",
    role: "Empresária",
    content:
      "Os perfumes da Lander Sozzi são simplesmente extraordinários. A qualidade é incomparável e as fragrâncias duram o dia todo. Não consigo mais usar outra marca!",
    rating: 5,
  },
  {
    id: 2,
    name: "Ricardo Mendes",
    role: "Advogado",
    content:
      "Noir Élégance se tornou minha assinatura. Recebo elogios constantemente e a fixação é impressionante. Vale cada centavo investido.",
    rating: 5,
  },
  {
    id: 3,
    name: "Juliana Costa",
    role: "Designer",
    content:
      "Rose Mystique é puro luxo em um frasco. A combinação de notas é perfeita e me faz sentir poderosa e elegante em qualquer ocasião.",
    rating: 5,
  },
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) =>
      prev === testimonials.length - 1 ? 0 : prev + 1
    );
  };

  const prev = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? testimonials.length - 1 : prev - 1
    );
  };

  return (
    <section className="py-24 bg-noir-light">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-elegant text-primary mb-4">Depoimentos</p>
          <h2 className="font-display text-3xl md:text-5xl text-foreground">
            O Que Dizem{" "}
            <span className="text-gradient-gold">Nossos Clientes</span>
          </h2>
        </div>

        {/* Testimonial Slider */}
        <div className="relative max-w-4xl mx-auto">
          <div className="glass-card p-8 md:p-12 relative">
            {/* Quote Icon */}
            <Quote
              size={60}
              className="absolute top-8 left-8 text-primary/20"
            />

            <div className="relative z-10">
              <p className="text-lg md:text-2xl text-foreground leading-relaxed mb-8 font-display italic">
                "{testimonials[currentIndex].content}"
              </p>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                  <span key={i} className="text-primary">
                    ★
                  </span>
                ))}
              </div>

              {/* Author */}
              <div>
                <p className="text-foreground font-medium">
                  {testimonials[currentIndex].name}
                </p>
                <p className="text-muted-foreground text-sm">
                  {testimonials[currentIndex].role}
                </p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-center gap-4 mt-8">
            <button
              onClick={prev}
              className="p-3 border border-border rounded-full hover:border-primary hover:text-primary transition-colors"
            >
              <ChevronLeft size={20} />
            </button>
            <div className="flex items-center gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? "bg-primary w-8"
                      : "bg-muted-foreground/30"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="p-3 border border-border rounded-full hover:border-primary hover:text-primary transition-colors"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
