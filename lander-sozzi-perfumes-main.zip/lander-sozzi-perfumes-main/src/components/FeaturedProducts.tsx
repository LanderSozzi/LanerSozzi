import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import ProductCard from "./ProductCard";
import { products } from "@/data/products";
import { Button } from "./ui/button";

const FeaturedProducts = () => {
  const featuredProducts = products.slice(0, 4);

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-elegant text-primary mb-4">Coleção Exclusiva</p>
          <h2 className="font-display text-3xl md:text-5xl text-foreground mb-6">
            Fragrâncias em{" "}
            <span className="text-gradient-gold">Destaque</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Descubra nossas criações mais aclamadas. Cada perfume é uma obra de
            arte olfativa, cuidadosamente elaborada para despertar emoções
            únicas.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/colecao">
            <Button variant="goldOutline" size="lg" className="group">
              Ver Coleção Completa
              <ArrowRight
                size={18}
                className="ml-2 transition-transform group-hover:translate-x-1"
              />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
